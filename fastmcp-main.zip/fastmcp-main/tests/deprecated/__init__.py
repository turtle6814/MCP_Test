# Tests for deprecated features - deprecation warnings are suppressed via conftest.py
